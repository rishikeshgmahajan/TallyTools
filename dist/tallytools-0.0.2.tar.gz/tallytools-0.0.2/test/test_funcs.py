from TallyTools import TallyMark as tm

t1 = tm("")

print(t1.type_of())